import { Injectable } from '@nestjs/common';
import { AutomationService } from '../automation/automation.service';
import { DentistService } from '../integrations/dentist/dentist.service';

@Injectable()
export class FlowService {
  constructor(
    private readonly dentistService: DentistService,
    private readonly automationService: AutomationService,
  ) {}

  async processIncomingMessage(input: {
    phone: string;
    message: string;
    firstName?: string;
    lastName?: string;
    middleName?: string;
    branchId?: number;
  }) {
    let patient = await this.dentistService.findPatientByPhone(input.phone);

    let patientCreated = false;

    if (!patient) {
      patient = await this.dentistService.createPatient({
        firstName: input.firstName || 'Новый',
        lastName: input.lastName || 'Пациент',
        middleName: input.middleName,
        phone: input.phone,
        branchId: input.branchId,
      });

      patientCreated = true;
    }

    const automation = this.automationService.handleNewIncomingMessage({
      phone: input.phone,
      message: input.message,
    });

    return {
      ok: true,
      patientCreated,
      patient,
      automation,
      nextAction: 'continue_booking_or_operator_processing',
    };
  }

  async processSuccessfulVisitCreation(input: {
    patientId: number;
    doctorId: number;
    branchId: number;
    start: string;
    end: string;
  }) {
    return this.automationService.handleVisitCreated(input);
  }

  async processPatientArrived(input: {
    patientId: number;
    visitId: number;
  }) {
    return this.automationService.handlePatientArrived(input);
  }

  async processPatientNoShow(input: {
    patientId: number;
    visitId: number;
  }) {
    return this.automationService.handlePatientNoShow(input);
  }
}
