import { Module } from '@nestjs/common';
import { AutomationModule } from '../automation/automation.module';
import { DentistModule } from '../integrations/dentist/dentist.module';
import { FlowController } from './flow.controller';
import { FlowService } from './flow.service';

@Module({
  imports: [DentistModule, AutomationModule],
  controllers: [FlowController],
  providers: [FlowService],
})
export class FlowModule {}
